<!DOCTYPE html>
<html>
<head>
    <title>Bienvenido</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="Background-color:SlateGray;">
    <div class="container" style="Color:white;" align="center">
        
        <FONT FACE="cursive" SIZE=10 COLOR="white"> Bienvenido, {{ $username ?? '' }}!</FONT>
        <p>Has iniciado sesión {{ $numLogins ?? '' }} veces.</p>
        <img src="https://media.tenor.com/uaQMpccz_yYAAAAd/out-west-travis-scott.gif">
    </div>
</body>
</html>

