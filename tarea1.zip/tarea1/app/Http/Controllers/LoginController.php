<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Cuenta;
use Illuminate\Support\Facades\DB;


class LoginController extends Controller
{

    public function login(Request $request)
{
    $username = $request->input('NombreUsuario');
    $password = $request->input('Contrasena');

    $user = Cuenta::where('NombreUsuario', $username)->first();

    if ($user && Hash::check($password, $user->Contrasena)) {
        DB::table('Cuenta')
	    ->where('NombreUsuario', $username)
	    ->increment('Logeos');

        return redirect('/welcome/' . $username);
    } else {
        return redirect('/login')->with('message', 'Incorrect username or password');
    }
    
    
}
    /*public function login(Request $request)
    {
        $username = $request->input('NombreUsuario');
        $password = $request->input('Contrasena');
        
        $credentials = [
            'NombreUsuario' => $username,
            'Contrasena' => $password
        ];
        
        $user = Cuenta::where('NombreUsuario', $username)->first();
        
        if(Hash::check($password, $user->Contrasena)) {
	    return true;
	}
        
        $query = DB::select( DB::raw("SELECT * FROM Cuenta WHERE NombreUsuario = '$username' AND Contrasena = '$password'"));
        
        //$this->hasher->check($plain, $user->getAuthPassword());
        
        //$query = DB::table('Cuenta')->where('NombreUsuario', $username)->where('Contrasena', $password);

        //if (Auth::guard('cuenta')->attempt($credentials)) {
        if($query){
            DB::table('Cuenta')
	    ->where('NombreUsuario', $username)
	    ->increment('Logeos');
            return redirect('/welcome/' . $username);        

        //if (Auth::attempt(['NombreUsuario' => $username, 'Contrasena' => $password])) {
        //    return redirect('/welcome');
        } else {
            return redirect('/login')->with('message', 'Incorrect username or password');
        }
    }*/

}
